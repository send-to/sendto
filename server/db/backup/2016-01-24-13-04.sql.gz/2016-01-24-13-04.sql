--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.pages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fragmenta_metadata ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.files ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.pages_id_seq;
DROP TABLE public.pages;
DROP SEQUENCE public.fragmenta_metadata_id_seq;
DROP TABLE public.fragmenta_metadata;
DROP SEQUENCE public.files_id_seq;
DROP TABLE public.files;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: kenny
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO kenny;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: kenny
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: files; Type: TABLE; Schema: public; Owner: sendto_server; Tablespace: 
--

CREATE TABLE files (
    id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    sender_id integer,
    status integer,
    path text,
    user_id integer,
    sender text
);


ALTER TABLE public.files OWNER TO sendto_server;

--
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: sendto_server
--

CREATE SEQUENCE files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.files_id_seq OWNER TO sendto_server;

--
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sendto_server
--

ALTER SEQUENCE files_id_seq OWNED BY files.id;


--
-- Name: fragmenta_metadata; Type: TABLE; Schema: public; Owner: sendto_server; Tablespace: 
--

CREATE TABLE fragmenta_metadata (
    id integer NOT NULL,
    updated_at timestamp without time zone,
    fragmenta_version text,
    migration_version text,
    status integer
);


ALTER TABLE public.fragmenta_metadata OWNER TO sendto_server;

--
-- Name: fragmenta_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: sendto_server
--

CREATE SEQUENCE fragmenta_metadata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fragmenta_metadata_id_seq OWNER TO sendto_server;

--
-- Name: fragmenta_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sendto_server
--

ALTER SEQUENCE fragmenta_metadata_id_seq OWNED BY fragmenta_metadata.id;


--
-- Name: pages; Type: TABLE; Schema: public; Owner: sendto_server; Tablespace: 
--

CREATE TABLE pages (
    id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    status integer,
    name text,
    summary text,
    url text,
    keywords text,
    text text
);


ALTER TABLE public.pages OWNER TO sendto_server;

--
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: sendto_server
--

CREATE SEQUENCE pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pages_id_seq OWNER TO sendto_server;

--
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sendto_server
--

ALTER SEQUENCE pages_id_seq OWNED BY pages.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: sendto_server; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    password text,
    status integer,
    name text,
    summary text,
    key text,
    email text,
    role integer
);


ALTER TABLE public.users OWNER TO sendto_server;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: sendto_server
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO sendto_server;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sendto_server
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sendto_server
--

ALTER TABLE ONLY files ALTER COLUMN id SET DEFAULT nextval('files_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sendto_server
--

ALTER TABLE ONLY fragmenta_metadata ALTER COLUMN id SET DEFAULT nextval('fragmenta_metadata_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sendto_server
--

ALTER TABLE ONLY pages ALTER COLUMN id SET DEFAULT nextval('pages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sendto_server
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: sendto_server
--

COPY files (id, created_at, updated_at, sender_id, status, path, user_id, sender) FROM stdin;
1	2016-01-23 14:40:24.35	2016-01-23 14:40:24.35	\N	\N	\N	\N	\N
2	2016-01-23 14:45:30.323	2016-01-23 14:45:30.323	\N	\N	\N	\N	\N
3	2016-01-23 14:45:59.762	2016-01-23 14:45:59.762	\N	\N	\N	\N	\N
4	2016-01-23 14:58:22.756	2016-01-23 14:58:22.76	\N	\N	files/4/testing.zip.gpg	\N	\N
5	2016-01-23 15:08:45.389	2016-01-23 15:08:45.392	\N	\N	files/5/testing.zip.gpg.zip.gpg	\N	\N
6	2016-01-23 15:10:02.088	2016-01-23 15:10:02.091	\N	\N	files/6/testing.zip.gpg	\N	\N
7	2016-01-23 15:15:09.714	2016-01-23 15:15:09.715	\N	\N	files/7/testing.zip.gpg	\N	\N
8	2016-01-23 16:24:41.695	2016-01-23 16:24:41.697	\N	\N	files/8/testing.zip.gpg	\N	\N
9	2016-01-23 16:27:06.063	2016-01-23 16:27:06.066	\N	\N	files/9/testing.zip.gpg	1	Kenny Grant
10	2016-01-23 16:29:22.853	2016-01-23 16:29:22.856	\N	\N	files/10/testing.zip.gpg	\N	Kenny Grant
\.


--
-- Name: files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sendto_server
--

SELECT pg_catalog.setval('files_id_seq', 10, true);


--
-- Data for Name: fragmenta_metadata; Type: TABLE DATA; Schema: public; Owner: sendto_server
--

COPY fragmenta_metadata (id, updated_at, fragmenta_version, migration_version, status) FROM stdin;
1	2016-01-23 08:01:17.109529	1.3.1	2016-01-23-075908-Create-Database.sql	100
2	2016-01-23 08:01:17.110707	1.3.1	2016-01-23-075908-Create-Tables.sql	100
3	2016-01-23 14:13:33.772241	1.3.1	2016-01-23-141305-Create-File.sql	100
4	2016-01-23 16:18:40.27938	1.3.1	2016-01-23-161159-Create-Page.sql	100
5	2016-01-23 16:18:40.280303	1.3.1	2016-01-23-161331-Create-Page.sql	100
6	2016-01-23 16:18:40.280802	1.3.1	2016-01-23-161502-Create-Page.sql	100
7	2016-01-23 16:18:40.281326	1.3.1	2016-01-23-161803-Create-User.sql	100
8	2016-01-24 10:22:00.033953	1.3.1	2016-01-24-102126-AddPageText.sql	100
\.


--
-- Name: fragmenta_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sendto_server
--

SELECT pg_catalog.setval('fragmenta_metadata_id_seq', 8, true);


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: sendto_server
--

COPY pages (id, created_at, updated_at, status, name, summary, url, keywords, text) FROM stdin;
3	2016-01-24 13:02:39.147	2016-01-24 13:03:46.221	100	Privacy Policy	Sendto respects your privacy. 	/privacy		<section class="feature">\r\n<div class="container">\r\n<h1>Privacy Policy</h1>\r\n<p>We respect your privacy, and will not share your person details or files with third parties. Sendto does not have access to the encrypted files uploaded.</p>\r\n<h3><br></h3>\r\n<h3>Cookies</h3>\r\n<p>This site uses cookies to store login information. By logging in you accept the use of cookies. Cookies may also be stored for third party analytics services like Google Analytics, which preserve your anonymity. </p>\r\n<h3>Changes</h3>\r\n<p>We reserve the right, at our sole discretion, to modify or replace this Privacy Policy at any time in accordance with Section 9 (“Changes to this Privacy Policy”). Access to the Service is offered to you conditioned on your acceptance without modification of this Privacy Policy.</p>\r\n<h3>Security</h3>\r\n<p>This site is protected by tls using a cert provided by lets encrypt. Your files are encrypted with the Go OpenPGP crypto libraries, source is available online. </p>\r\n<h3>Contact </h3>\r\n<p>Contact info coming soon. </p>\r\n<p><br></p>\r\n<p><br></p>\r\n</div>\r\n</section>
1	2016-01-24 10:12:22.327	2016-01-24 12:11:25.147	100	Send To	Send To	/	send to	<section class="feature">\r\n\r\n<div class="container">\r\n<h1><i class="fa fa-send"></i>&nbsp;Send to...</h1>\r\n<div><br></div>\r\n<h3>Sendto lets people send you encrypted files and folders, without knowing about encryption, keys or passwords. </h3><div><br></div>\r\n</div>\r\n\r\n<div class="row container bullets">\r\n<div class="four columns">\r\n<h2><i class="fa fa-lock"></i> Secure</h2>\r\n<ul>\r\n<li>Uses only public keys</li>\r\n<li>PGP encryption</li>\r\n<li>No passwords or key exchange</li>\r\n<li>Crypto by Adam Langley</li>\r\n</ul>\r\n</div>\r\n<div class="four columns">\r\n<h2><i class="fa fa-gift"></i> Easy</h2>\r\n<ul>\r\n<li>Just upload your <i>public</i> key</li>\r\n<li>No passwords or key generation</li>\r\n<li>Clients send files with a simple command</li>\r\n</ul>\r\n</div>\r\n<div class="four columns">\r\n<h2><a href="https://github.com/gophergala/sendto"><i class="fa fa-github"></i> Open</a></h2>\r\n<ul>\r\n<li>All source code on Github</li>\r\n<li>Use keys from &nbsp;keybase.io</li>\r\n<li>Self-hosting option</li>\r\n<li>Cross platform client software</li>\r\n</ul>\r\n</div>\r\n</div>\r\n<p><a class="button" href="http://localhost:3000/users/create" style="font-size: 16px; background-color: rgb(5, 175, 231);">TRY IT</a><br></p>\r\n</section>\r\n\r\n<section>\r\n<h2>How does it work?</h2>\r\n<p>Just send people a link to your profile, and they can download an app for their platform to send you encrypted files. After that download, on Mac OS X they can send you sensitive files just by right clicking a file or folder and choosing Services &gt; Send to..., at which point you can see it on the website. The OS X, Linux and Windows platforms all have a simple command line app available.<br></p>\r\n<p>To send files, use:</p>\r\n<pre><code>sendto username mylocalfolderorfiles</code></pre>\r\n<p>The sendto client will fetch the public key of user <i>username</i>, encrypt the files with it, and send the files off to the server. The server will then optionally send an email to the user concerned, and they can log in and download the files. Because the server can't decrypt the files it stores, you can trust that no-one but the intended recipient can open them, even if the server was compromised.  </p>\r\n<p>For extra security you can choose to run your own server as well as client. </p>\r\n</section>\r\n\r\n<section class="feature">\r\n<h2><br></h2>\r\n<h2>Cross-platform encryption</h2><div><br></div><div><br></div>\r\n<div class="row container">\r\n<div class="four columns">\r\n<h3><i class="fa fa-apple fa-4x"></i><br>Mac</h3>\r\n</div>\r\n<div class="four columns">\r\n<h3><i class="fa fa-linux fa-4x"></i><br>Linux</h3>\r\n</div>\r\n<div class="four columns">\r\n<h3><i class="fa fa-windows fa-4x"></i><br>Windows</h3>\r\n</div>\r\n</div>\r\n<p><br><br></p>\r\n<p><a class="button" href="/users/create">REGISTER</a></p>\r\n</section>
2	2016-01-24 12:54:07.432	2016-01-24 12:54:26.795	100	About	About this site	/about	encryption pgp easy mac	<section>\r\n<h1>About Sendto</h1><div>Sendto was written for Gopher Gala 2016 by <a href="https://twitter.com/kennygrant">@kennygrant</a></div>\r\n</section>
\.


--
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sendto_server
--

SELECT pg_catalog.setval('pages_id_seq', 3, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: sendto_server
--

COPY users (id, created_at, updated_at, password, status, name, summary, key, email, role) FROM stdin;
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sendto_server
--

SELECT pg_catalog.setval('users_id_seq', 1, false);


--
-- Name: public; Type: ACL; Schema: -; Owner: kenny
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM kenny;
GRANT ALL ON SCHEMA public TO kenny;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

