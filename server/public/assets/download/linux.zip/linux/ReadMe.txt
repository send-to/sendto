### Installation

Move the binary sendto your preferred /bin directory, use /usr/local/bin if you are unsure. You should then be able to call the command sendto.

Then on the command line send files by specifying the sendto user to send them to, and the path to the file or folder you want to send:

sendto username path/to/folder

sendto will zip and encrypt the files, and send them to the user you have chosen. 

For more information, see the website at:

https://sendto.click/